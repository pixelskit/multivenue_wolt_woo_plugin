<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       
 * @since      1.0.0
 *
 * @package    Pixelskit_Wolt
 * @subpackage Pixelskit_Wolt/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Pixelskit_Wolt
 * @subpackage Pixelskit_Wolt/admin
 * @author     PixelsKit
 */
class Webexpert_Woocommerce_Wolt_Inventory_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct( $plugin_name, $version ) {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles($hook) {
        if ( $hook !== 'pixelskit_page_pixelskit-wolt' ) {
            return;
        }
        if( ! wp_style_is( 'select2', 'registered' ) ) {
            wp_register_style( 'select2', WC()->plugin_url() . '/assets/css/select2.css', null, $this->version );
        }
        wp_enqueue_style( 'select2' );
        wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/webexpert-woocommerce-wolt-inventory-admin.css', array(), $this->version, 'all' );

    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts($hook) {
        if ( $hook !== 'pixelskit_page_pixelskit-wolt' ) {
            return;
        }
        if( ! wp_script_is( 'select2', 'registered' ) ) {
            wp_register_script( 'select2', WC()->plugin_url() . '/assets/js/select2/select2.full.min.js', array( 'jquery' ), $this->version );
        }
        wp_enqueue_script('select2');
        wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/webexpert-woocommerce-wolt-inventory-admin.js', array( 'jquery' ), $this->version, false );
        wp_localize_script($this->plugin_name, 'webexpert_wolt_inv_ajax_object', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('pixelskit_wolt_admin_action'),
        ));
    }

    public function webexpert_wolt_inventory_options_page() {
        $logo = file_get_contents(plugin_dir_path(__DIR__).'assets/pixelskit-icon.svg');
        if ( empty ( $GLOBALS['admin_page_hooks']['pixelskit_plugins'] ) )
            add_menu_page('PixelsKit Plugins','PixelsKit','manage_woocommerce','pixelskit_plugins',[$this,'webexpert_wolt_inventory_options_page_html'],'data:image/svg+xml;base64,' . base64_encode($logo),20);
        add_submenu_page('pixelskit_plugins',__( 'pixelskit-wolt', $this->plugin_name ), __( 'pixelskit-wolt', $this->plugin_name ),'manage_woocommerce','pixelskit-wolt',[$this,'webexpert_wolt_inventory_options_page_html']
        );
        remove_submenu_page('pixelskit_plugins',    'pixelskit_plugins');
    }

    public function webexpert_wolt_inventory_settings() {
        register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_venue_id' );
        register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_api_username' );
        register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_api_password' );
        register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_environment' );
        register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_partial_send' );
        register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_disable_images' );
        register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_disable_prices' );
	    register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_variations_on_item_update' );
        register_setting( 'webexpert-wolt-inventory-group', 'we_wolt_inventory_categories_not_to_list' );
        register_setting( 'webexpert-wolt-inventory-group', 'we_wolt_inventory_tags_not_to_list' );
        register_setting( 'webexpert-wolt-inventory-group', 'we_wolt_inventory_attributes_not_to_list' );
        register_setting( 'webexpert-wolt-inventory-group', 'we_wolt_inventory_categories_not_to_list_invert' );
        register_setting( 'webexpert-wolt-inventory-group', 'we_wolt_inventory_tags_not_to_list_invert' );
        register_setting( 'webexpert-wolt-inventory-group', 'we_wolt_inventory_attributes_not_to_list_invert' );
        register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_desc_field' );
        register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_orderapi_key' );
	    register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_generate_xml' );
	    register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_size' );
	    register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_debug' );
	    register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_custom_ean' );
	    register_setting( 'webexpert-wolt-inventory-group', 'webexpert_wolt_inventory_custom_sku' );
    }

    private function split_setting_values( $value ) {
        if ( is_array( $value ) ) {
            $values = $value;
        } else {
            $values = preg_split( '/[\r\n,;]+/', (string) $value );
        }

        $values = array_map( 'trim', $values );
        $values = array_filter( $values, 'strlen' );

        return array_values( array_unique( $values ) );
    }

    private function ensure_admin_ajax_permission() {
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            return;
        }

        if ( ! check_ajax_referer( 'pixelskit_wolt_admin_action', 'nonce', false ) || ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( __( 'Unauthorized', $this->plugin_name ), 403 );
        }
    }

    private function get_wolt_venue_ids() {
        $venue_ids = $this->split_setting_values( get_option( 'webexpert_wolt_inventory_venue_id', '' ) );

        return apply_filters( 'webexpert_wolt_inventory_venue_ids', $venue_ids );
    }

    private function get_wolt_order_api_keys() {
        $api_keys = $this->split_setting_values( get_option( 'webexpert_wolt_inventory_orderapi_key', '' ) );

        return apply_filters( 'webexpert_wolt_inventory_order_api_keys', $api_keys );
    }

    private function get_wolt_base_url() {
        if ( get_option( 'webexpert_wolt_inventory_environment', 'test' ) == 'test' ) {
            return 'https://pos-integration-service.development.dev.woltapi.com';
        }

        return 'https://pos-integration-service.wolt.com';
    }

    private function get_wolt_pos_headers( $venue_id = '' ) {
        $credentials = apply_filters( 'webexpert_wolt_inventory_venue_credentials', [
            'username' => get_option( 'webexpert_wolt_inventory_api_username', '' ),
            'password' => get_option( 'webexpert_wolt_inventory_api_password', '' ),
        ], $venue_id );

        $username = isset( $credentials['username'] ) ? $credentials['username'] : '';
        $password = isset( $credentials['password'] ) ? $credentials['password'] : '';

        return [
            'Authorization' => 'Basic ' . base64_encode( $username . ':' . $password ),
            'Content-Type'  => 'application/json; charset=utf-8',
        ];
    }

    private function get_wolt_url( $path ) {
        return trailingslashit( $this->get_wolt_base_url() ) . ltrim( $path, '/' );
    }

    private function wolt_pos_request( $venue_id, $path, $method = 'PATCH', $body = null, $timeout = 30 ) {
        $args = [
            'method'      => $method,
            'timeout'     => $timeout,
            'redirection' => 5,
            'headers'     => $this->get_wolt_pos_headers( $venue_id ),
        ];

        if ( $body !== null ) {
            $args['body'] = is_string( $body ) ? $body : json_encode( $body );
        }

        return wp_remote_request( $this->get_wolt_url( $path ), $args );
    }

    private function log_wolt_payload( $source, $payload, $venue_id = '' ) {
        if ( get_option( 'webexpert_wolt_debug', null ) != '1' ) {
            return;
        }

        $logger = wc_get_logger();
        $logger->info(
            wc_print_r( json_encode( [
                'venue_id' => $venue_id,
                'payload'  => $payload,
            ], JSON_UNESCAPED_UNICODE ), true ),
            [ 'source' => $source ]
        );
    }

    private function format_wolt_response_error( $venue_id, $request ) {
        if ( is_wp_error( $request ) ) {
            return sprintf( 'Venue %s: %s', $venue_id, $request->get_error_message() );
        }

        $response_code = wp_remote_retrieve_response_code( $request );
        $response_body = wp_remote_retrieve_body( $request );

        return sprintf( 'Venue %s: HTTP %s %s', $venue_id, $response_code, $response_body );
    }

    private function send_wolt_payload_to_venues( $path_template, $payload, $source, $expected_code = 202, $method = 'PATCH' ) {
        $venue_ids = $this->get_wolt_venue_ids();
        if ( empty( $venue_ids ) ) {
            return new WP_Error( 'wolt_missing_venues', __( 'No Wolt venue IDs configured.', $this->plugin_name ) );
        }

        $errors = [];
        foreach ( $venue_ids as $venue_id ) {
            $path = sprintf( $path_template, rawurlencode( $venue_id ) );
            $this->log_wolt_payload( $source, $payload, $venue_id );

            $request = $this->wolt_pos_request( $venue_id, $path, $method, $payload );
            if ( is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) !== $expected_code ) {
                $errors[] = $this->format_wolt_response_error( $venue_id, $request );
            }
        }

        if ( ! empty( $errors ) ) {
            return new WP_Error( 'wolt_sync_failed', implode( "\n", $errors ) );
        }

        return $venue_ids;
    }

    private function fetch_wolt_order( $order_id ) {
        $api_keys = $this->get_wolt_order_api_keys();
        if ( empty( $api_keys ) ) {
            return new WP_Error( 'wolt_missing_order_api_keys', __( 'No Wolt Order API keys configured.', $this->plugin_name ) );
        }

        $last_error = '';
        foreach ( $api_keys as $api_key ) {
            $request = wp_remote_get( $this->get_wolt_url( 'orders/' . rawurlencode( $order_id ) ), [
                'redirection' => 5,
                'headers'     => [
                    'WOLT-API-KEY' => $api_key,
                    'Content-Type' => 'application/json; charset=utf-8',
                ],
            ] );

            if ( is_wp_error( $request ) ) {
                $last_error = $request->get_error_message();
                continue;
            }

            $response_code = wp_remote_retrieve_response_code( $request );
            $response_body = wp_remote_retrieve_body( $request );
            if ( $response_code === 200 ) {
                return json_decode( $response_body );
            }

            $decoded    = json_decode( $response_body );
            $last_error = ! empty( $decoded->msg ) ? $decoded->msg : $response_body;
        }

        return new WP_Error( 'wolt_order_fetch_failed', $last_error ?: __( 'Failed to fetch Wolt order.', $this->plugin_name ) );
    }

    private function get_wolt_order_venue_id( $wolt_order ) {
        $venue_id = '';
        if ( ! empty( $wolt_order->venue_id ) ) {
            $venue_id = $wolt_order->venue_id;
        } elseif ( ! empty( $wolt_order->venue->id ) ) {
            $venue_id = $wolt_order->venue->id;
        }

        return apply_filters( 'webexpert_wolt_inventory_order_venue_id', $venue_id, $wolt_order );
    }

    private function get_wolt_menu_disabled_items( $venue_id, $assembled ) {
        $request = $this->wolt_pos_request( $venue_id, 'v2/venues/' . rawurlencode( $venue_id ) . '/menu', 'GET', null );
        if ( is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) !== 202 ) {
            return new WP_Error( 'wolt_menu_fetch_failed', $this->format_wolt_response_error( $venue_id, $request ) );
        }

        $response_body = json_decode( wp_remote_retrieve_body( $request ), true );
        if ( empty( $response_body['resource_url'] ) ) {
            return [];
        }

        sleep( 5 );

        $menu_request = wp_remote_get( $response_body['resource_url'], [
            'headers' => [
                'Content-Type' => 'application/json; charset=utf-8',
            ],
        ] );

        if ( is_wp_error( $menu_request ) ) {
            return new WP_Error( 'wolt_menu_resource_failed', $menu_request->get_error_message() );
        }

        $menu_response_body = json_decode( wp_remote_retrieve_body( $menu_request ), true );
        if ( empty( $menu_response_body['status'] ) || $menu_response_body['status'] !== 'READY' || empty( $menu_response_body['menu']['items'] ) ) {
            return [];
        }

        $wolt_enabled = [];
        foreach ( $menu_response_body['menu']['items'] as $menu_item ) {
            if ( ! empty( $menu_item['enabled']['enabled'] ) && ! empty( $menu_item['product']['sku'] ) ) {
                $wolt_enabled[ $menu_item['product']['sku'] ] = 1;
            }
        }

        $disabled_items = [];
        foreach ( array_diff_key( $wolt_enabled, $assembled ) as $sku => $enabled ) {
            $disabled_items[] = [ 'sku' => $sku, 'enabled' => false ];
        }

        return $disabled_items;
    }

    public function webexpert_wolt_inventory_options_page_html() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }
        $active_tab    = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'settings';
        if ( ! in_array( $active_tab, [ 'settings', 'actions' ], true ) ) {
            $active_tab = 'settings';
        }
        ?>
        <div class="wrap webexpert-wolt-inventory-settings-wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <nav class="nav-tab-wrapper">
                <a href="?page=pixelskit-wolt&tab=settings" class="nav-tab <?php echo $active_tab === 'settings' ? 'nav-tab-active' : ''; ?>"><?php _e('Settings', $this->plugin_name); ?></a>
                <a href="?page=pixelskit-wolt&tab=actions" class="nav-tab <?php echo $active_tab === 'actions' ? 'nav-tab-active' : ''; ?>"><?php _e('Actions', $this->plugin_name); ?></a>
            </nav>

            <form action="options.php" method="post">
                <?php
                settings_fields('webexpert-wolt-inventory-group');
                do_settings_sections('webexpert-wolt-inventory-group');
                ?>

                <?php // -- TAB: Settings -- ?>
                <div class="webexpert-wolt-inventory-tab-content" id="tab-settings" <?php echo $active_tab !== 'settings' ? 'style="display:none"' : ''; ?>>

                <div class="webexpert-wolt-inventory-section">
                    <h3 class="webexpert-wolt-inventory-section-title"><?php _e('Settings', $this->plugin_name); ?></h3>
                    <div class="webexpert-wolt-inventory-section-body">
                <table class="form-table">
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_venue_id"><?php _e('Venue IDs',$this->plugin_name);?></label</th>
                        <td>
                            <textarea id="webexpert_wolt_inventory_venue_id" name="webexpert_wolt_inventory_venue_id" rows="4" class="large-text"><?php echo esc_textarea( get_option('webexpert_wolt_inventory_venue_id','') ); ?></textarea>
                            <p class="description"><?php _e('Add one or more Wolt venue IDs, separated by new lines or commas. Inventory, item, option, and manual sync actions will run for every venue.', $this->plugin_name); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_api_username"><?php _e('API username',$this->plugin_name);?></label</th>
                        <td><input type="text" id="webexpert_wolt_inventory_api_username" name="webexpert_wolt_inventory_api_username" value="<?php echo get_option('webexpert_wolt_inventory_api_username',''); ?>" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_api_password"><?php _e('API password',$this->plugin_name);?></label</th>
                        <td><input type="text" id="webexpert_wolt_inventory_api_password" name="webexpert_wolt_inventory_api_password" value="<?php echo get_option('webexpert_wolt_inventory_api_password',''); ?>" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_orderapi_key"><?php _e('OrderAPI Keys',$this->plugin_name);?></label</th>
                        <td>
                            <textarea id="webexpert_wolt_inventory_orderapi_key" name="webexpert_wolt_inventory_orderapi_key" rows="3" class="large-text"><?php echo esc_textarea( get_option('webexpert_wolt_inventory_orderapi_key','') ); ?></textarea>
                            <p class="description"><?php _e('Add one or more Wolt Order API keys. Manual fetches and webhooks will try each key until the order is found.', $this->plugin_name); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_partial_send"><?php _e('Partial send (recommended)',$this->plugin_name);?></label</th>
                        <td><input type="checkbox" id="webexpert_wolt_inventory_partial_send" name="webexpert_wolt_inventory_partial_send" value="yes" <?php echo checked("yes",get_option('webexpert_wolt_inventory_partial_send','yes')); ?> /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_disable_images"><?php _e('Disable images',$this->plugin_name);?></label</th>
                        <td><label for="webexpert_wolt_inventory_disable_images"><input type="checkbox" id="webexpert_wolt_inventory_disable_images" name="webexpert_wolt_inventory_disable_images" value="yes" <?php echo checked("yes",get_option('webexpert_wolt_inventory_disable_images','')); ?> />
                            <?php _e('Enable this option in order to stop images sync on Wolt and set up the prices manually',$this->plugin_name);?></label></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_disable_prices"><?php _e('Disable prices',$this->plugin_name);?></label</th>
                        <td><label for="webexpert_wolt_inventory_disable_prices"><input type="checkbox" id="webexpert_wolt_inventory_disable_prices" name="webexpert_wolt_inventory_disable_prices" value="yes" <?php echo checked("yes",get_option('webexpert_wolt_inventory_disable_prices','')); ?> />
                            <?php _e('Enable this option in order to stop price sync on Wolt and set up the prices manually',$this->plugin_name);?></label>
                        </td>
                    </tr>

                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_variations_on_item_update"><?php _e('Variations on item update',$this->plugin_name);?></label</th>
                        <td><label for="webexpert_wolt_inventory_variations_on_item_update"><input type="checkbox" id="webexpert_wolt_inventory_variations_on_item_update" name="webexpert_wolt_inventory_variations_on_item_update" value="yes" <?php echo checked("yes",get_option('webexpert_wolt_inventory_variations_on_item_update','')); ?> /> <?php _e('Enable this to include variation on main item update (upon request)',$this->plugin_name);?></label></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e('Environment',$this->plugin_name);?></th>
                        <td>
                            <label><input type="radio" id="webexpert_wolt_inventory_environment_test" name="webexpert_wolt_inventory_environment" value="test" <?php echo checked("test",get_option('webexpert_wolt_inventory_environment','test')); ?> /> <?php _e('Test',$this->plugin_name);?></label>
                            &nbsp; <label><input type="radio" id="webexpert_wolt_inventory_environment_production" name="webexpert_wolt_inventory_environment" value="live" <?php echo checked('live',get_option('webexpert_wolt_inventory_environment','test')); ?> /> <?php _e('Live',$this->plugin_name);?></label>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e('Description',$this->plugin_name);?></th>
                        <td>
                            <fieldset><legend class="screen-reader-text"><span><?php _e('Description',$this->plugin_name);?></span></legend>
                                <label> <input type="radio" name="webexpert_wolt_inventory_desc_field" value="short" <?php echo get_option('webexpert_wolt_inventory_desc_field','short')=='short' ? 'checked' : '';?>> <span><?php _e('Short description',$this->plugin_name);?></span> </label><br>
                                <label> <input type="radio" name="webexpert_wolt_inventory_desc_field" value="long" <?php echo get_option('webexpert_wolt_inventory_desc_field','short')=='long' ? 'checked' : '';?>> <span><?php _e('Description',$this->plugin_name);?></span> </label>
                            </fieldset>
                        </td>
                    </tr>
                    <tr valign="top">
                            <th scope="row"><label for="webexpert_wolt_inventory_custom_sku"><?php _e('Custom Product SKU field',$this->plugin_name);?></label></th>
                            <td><input type="text" id="webexpert_wolt_inventory_custom_sku" name="webexpert_wolt_inventory_custom_sku" value="<?php echo esc_attr( get_option('webexpert_wolt_inventory_custom_sku') ); ?>" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_custom_ean"><?php _e('Custom Product EAN field',$this->plugin_name);?></label></th>
                        <td><input type="text" id="webexpert_wolt_inventory_custom_ean" name="webexpert_wolt_inventory_custom_ean" value="<?php echo esc_attr( get_option('webexpert_wolt_inventory_custom_ean') ); ?>" /></td>
                    </tr>
                    </table>
                    </div>
                </div>

                <div class="webexpert-wolt-inventory-section">
                    <h3 class="webexpert-wolt-inventory-section-title"><?php _e('Products', $this->plugin_name); ?></h3>
                    <div class="webexpert-wolt-inventory-section-body">
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><label for="webexpert_wolt_inventory_size"><?php _e('Size',$this->plugin_name);?></label></th>
                        <td>
			                <?php
			                $selected_size=get_option('webexpert_wolt_inventory_size',[]);
			                ?>
                            <select id="webexpert_wolt_inventory_size" name="webexpert_wolt_inventory_size[]" multiple>
				                <?php
				                $attribute_taxonomies = wc_get_attribute_taxonomies();;
                                foreach ($attribute_taxonomies as $atr) { ?>
                                    <option value="<?php echo $atr->attribute_name;?>"  <?php echo ((is_string($selected_size) && $selected_size==$atr->attribute_name) || (is_array($selected_size) && in_array($atr->attribute_name,$selected_size)) ? 'selected' : '' );?> ><?php echo $atr->attribute_label; ?></option>
				                <?php } ?>
                            </select>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="we_wolt_inventory_categories_not_to_list"><a data-action="<?php echo (get_option('we_wolt_inventory_categories_not_to_list_invert',0) ? 'include' : 'exclude'); ?>" data-lang-exclude="<?php _e('Exclude',$this->plugin_name) ?>" data-lang-include="<?php _e('Include',$this->plugin_name) ?>" class="we-wolt-inventory-smart-switch"><?php _e((get_option('we_wolt_inventory_categories_not_to_list_invert', 0) ? 'Include' : 'Exclude'),$this->plugin_name) ?></a> <?php _e(' products from these categories',$this->plugin_name);?></label></th>
                        <td>
                            <?php $selected_terms=get_option('we_wolt_inventory_categories_not_to_list',[]);
                            if (empty($selected_terms))
                                $selected_terms=[];
                            ?>
                            <select id="we_wolt_inventory_categories_not_to_list" name="we_wolt_inventory_categories_not_to_list[]" multiple="multiple">
                                <?php
                                $terms=get_terms( 'product_cat', array( 'get' => 'all' ));
                                foreach ($terms as $term) {
                                    echo "<option value='$term->term_id' ".(in_array($term->term_id,$selected_terms) ? 'selected="selected"' : '').">$term->name</option>";
                                }
                                ?>
                            </select>
                            <input type="checkbox" id="we_wolt_inventory_categories_not_to_list_invert" class="we-wolt-inventory-smart-switch-checkbox" name="we_wolt_inventory_categories_not_to_list_invert" value="1" <?php echo (get_option('we_wolt_inventory_categories_not_to_list_invert',0) ? 'checked="checked"' : ''); ?>>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="we_wolt_inventory_tags_not_to_list"><a data-action="<?php echo (get_option('we_wolt_inventory_tags_not_to_list_invert',0) ? 'include' : 'exclude'); ?>" data-lang-exclude="<?php _e('Exclude',$this->plugin_name) ?>" data-lang-include="<?php _e('Include',$this->plugin_name) ?>" class="we-wolt-inventory-smart-switch"><?php _e((get_option('we_wolt_inventory_tags_not_to_list_invert', 0) ? 'Include' : 'Exclude'),$this->plugin_name) ?></a> <?php _e(' products with these tags',$this->plugin_name);?></label></th>
                        <td>
                            <?php $selected_terms=get_option('we_wolt_inventory_tags_not_to_list',[]);
                            if (empty($selected_terms))
                                $selected_terms=[];
                            ?>
                            <select id="we_wolt_inventory_tags_not_to_list" name="we_wolt_inventory_tags_not_to_list[]" multiple="multiple">
                                <?php
                                $terms=get_terms( 'product_tag', array( 'get' => 'all' ));
                                foreach ($terms as $term) {
                                    echo "<option value='$term->term_id' ".(in_array($term->term_id,$selected_terms) ? 'selected="selected"' : '').">$term->name</option>";
                                }
                                ?>
                            </select>
                            <input type="checkbox" id="we_wolt_inventory_tags_not_to_list_invert" class="we-wolt-inventory-smart-switch-checkbox" name="we_wolt_inventory_tags_not_to_list_invert" value="1" <?php echo (get_option('we_wolt_inventory_tags_not_to_list_invert',0) ? 'checked="checked"' : ''); ?>>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="we_wolt_inventory_attributes_not_to_list"><a data-action="<?php echo (get_option('we_wolt_inventory_attributes_not_to_list_invert',0) ? 'include' : 'exclude'); ?>" data-lang-exclude="<?php _e('Exclude',$this->plugin_name) ?>" data-lang-include="<?php _e('Include',$this->plugin_name) ?>" class="we-wolt-inventory-smart-switch"><?php _e((get_option('we_wolt_inventory_attributes_not_to_list_invert', 0) ? 'Include' : 'Exclude'),$this->plugin_name) ?></a> <?php _e(' products with these attributes',$this->plugin_name);?></label>
                        </th>
                        <td>
                            <?php $selected_terms=get_option('we_wolt_inventory_attributes_not_to_list',[]);
                            if (empty($selected_terms))
                                $selected_terms=[];
                            ?>
                            <select id="we_wolt_inventory_attributes_not_to_list" name="we_wolt_inventory_attributes_not_to_list[]" multiple="multiple">
                                <?php
                                $attribute_taxonomies = wc_get_attribute_taxonomies();
                                if ( $attribute_taxonomies ) {
                                    foreach ( $attribute_taxonomies as $taxonomy ) {
                                        $tax_name = 'pa_' . $taxonomy->attribute_name;
                                        if ( ! taxonomy_exists( $tax_name ) ) {
                                            continue;
                                        }
                                        $terms = get_terms( array(
                                                'taxonomy'   => $tax_name,
                                                'hide_empty' => false,
                                        ) );
                                        if ( is_wp_error( $terms ) || empty( $terms ) ) {
                                            continue;
                                        }
                                        foreach ( $terms as $term ) {
                                            echo "<option value='" . esc_attr( $term->term_id . "__" . $term->taxonomy ) . "' " . ( in_array( $term->term_id . "__" . $term->taxonomy, $selected_terms ) ? 'selected="selected"' : '' ) . ">" . esc_html( $taxonomy->attribute_label . ': ' . $term->name ) . "</option>";
                                        }
                                    }
                                } ?>
                            </select>
                            <input type="checkbox" id="we_wolt_inventory_attributes_not_to_list_invert" class="we-wolt-inventory-smart-switch-checkbox" name="we_wolt_inventory_attributes_not_to_list_invert" value="1" <?php echo (get_option('we_wolt_inventory_attributes_not_to_list_invert',0) ? 'checked="checked"' : ''); ?>>
                        </td>
                    </tr>
                </table>
                    </div>
                </div>

                <!-- ── Webhook card ── -->
                <div class="webexpert-wolt-inventory-section">
                    <h3 class="webexpert-wolt-inventory-section-title"><?php _e('Webhook', $this->plugin_name); ?></h3>
                    <table class="form-table">
                        <tr valign="top">
                            <th scope="row"><label for="wolt_inventory_webhook_url_field"><?php _e('Webhook URL', $this->plugin_name); ?></label></th>
                            <td>
                                <div class="we-wolt-input-action">
                                    <input type="text" readonly id="wolt_inventory_webhook_url_field" value="<?php echo esc_attr(get_rest_url(null, 'wc/v3/wolt_orders')); ?>" class="regular-text" style="background:#f9fafb;color:#50575e;" />
                                    <button type="button" class="button" id="wolt_inventory_copy_webhook_url"><?php _e('Copy', $this->plugin_name); ?></button>
                                </div>
                                <p class="description"><?php _e('Register this URL in the Wolt merchant dashboard to receive automatic order updates via webhook.', $this->plugin_name); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- ── Debug card ── -->
                <div class="webexpert-wolt-inventory-section">
                    <h3 class="webexpert-wolt-inventory-section-title"><?php _e('Debug', $this->plugin_name); ?></h3>
                    <div class="webexpert-wolt-inventory-section-body" style="padding: 12px 16px;">
                        <p><label for="webexpert_wolt_debug"><input name="webexpert_wolt_debug" type="checkbox" id="webexpert_wolt_debug" value="1" <?php echo get_option('webexpert_wolt_debug',0)==1 ? 'checked' : ''; ?>>
                        <?php _e('Debug mode logs every request made to Wolt',$this->plugin_name);?></label></p>
                    </div>
                </div>

                    <p class="submit we-submit-row">
                        <input type="submit" name="submit" class="button button-primary" value="<?php esc_attr_e('Save Settings', $this->plugin_name); ?>">
                    </p>

                </div><!-- /#tab-settings -->

                <?php // -- TAB: Actions -- ?>
                <div class="webexpert-wolt-inventory-tab-content" id="tab-actions" <?php echo $active_tab !== 'actions' ? 'style="display:none"' : ''; ?>>

                <!-- ── Order Fetch card ── -->
                <div class="webexpert-wolt-inventory-section">
                    <h3 class="webexpert-wolt-inventory-section-title"><?php _e('Order Fetch', $this->plugin_name); ?></h3>
                    <div class="webexpert-wolt-inventory-section-body" style="padding: 16px;">
                        <p style="margin-top:0;">
                            <label for="webexpert_wolt_inventory_order_id"><?php _e('Order ID:', $this->plugin_name); ?></label><br>
                            <input placeholder="<?php _e('eg.', $this->plugin_name); ?> 64366c753b265198ab7db161" type="text" id="webexpert_wolt_inventory_order_id" name="webexpert_wolt_inventory_order_id" class="regular-text" style="margin-top:6px;">
                        </p>
                        <div class="we-wolt-action-btns">
                            <button data-success="<?php _e('Order fetched with ID:', $this->plugin_name); ?>" data-fail="<?php _e('Failed to fetch order', $this->plugin_name); ?>" class="button button-primary we-wolt-action-btn has-spinner" type="button" id="wolt-xml-fetch_order"><?php _e('Fetch Order', $this->plugin_name); ?><span class="we_spinner"></span></button>
                        </div>
                    </div>
                </div>

                <!-- ── Sync card ── -->
                <div class="webexpert-wolt-inventory-section">
                    <h3 class="webexpert-wolt-inventory-section-title"><?php _e('Sync', $this->plugin_name); ?></h3>
                    <div class="webexpert-wolt-inventory-section-body" style="padding: 16px;">
                        <div class="we-wolt-stat-grid">
                            <div class="we-wolt-stat-card">
                                <div class="we-wolt-stat-value" id="wolt-inventory-update-inventory-label"><?php echo esc_html(get_option('webexpert_wolt_inventory_last_update', '—')); ?></div>
                                <div class="we-wolt-stat-label"><?php _e('Last inventory sync', $this->plugin_name); ?></div>
                                <button class="button button-primary we-wolt-action-btn has-spinner" type="button" id="wolt-inventory-update" style="margin-top:12px;"><?php _e('Inventory Update', $this->plugin_name); ?><span class="we_spinner"></span></button>
                            </div>
                            <div class="we-wolt-stat-card">
                                <div class="we-wolt-stat-value" id="wolt-inventory-update-label"><?php echo esc_html(get_option('webexpert_wolt_inventory_last_items_update', '—')); ?></div>
                                <div class="we-wolt-stat-label"><?php _e('Last items sync', $this->plugin_name); ?></div>
                                <button class="button button-primary we-wolt-action-btn has-spinner" type="button" id="wolt-items-update" style="margin-top:12px;"><?php _e('Items Update', $this->plugin_name); ?><span class="we_spinner"></span></button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ── Generate card ── -->
                <div class="webexpert-wolt-inventory-section">
                    <h3 class="webexpert-wolt-inventory-section-title"><?php _e('Generate', $this->plugin_name); ?></h3>
                    <div class="webexpert-wolt-inventory-section-body" style="padding: 16px;">
                        <?php
                        $upload_dir = wp_upload_dir();
                        $wolt_inventory_xml_dir      = $upload_dir['basedir'] . '/pixelskit-wolt';
                        $wolt_inventory_xml_dir_file = $wolt_inventory_xml_dir . '/products.xml';
                        $wolt_inventory_xml_url_file = $upload_dir['baseurl'] . '/pixelskit-wolt/products.xml';
                        $wolt_inventory_csv_dir_file = $wolt_inventory_xml_dir . '/products.csv';
                        $wolt_inventory_csv_url_file = $upload_dir['baseurl'] . '/pixelskit-wolt/products.csv';
                        wp_mkdir_p($wolt_inventory_xml_dir);
                        $last_xml = get_option('webexpert_wolt_inventory_generate_xml', '');
                        $xml_exists = file_exists($wolt_inventory_xml_dir_file);
                        $csv_exists = file_exists($wolt_inventory_csv_dir_file);
                        ?>
                        <div class="we-wolt-status-bar <?php echo $last_xml ? 'we-wolt-status-ok' : 'we-wolt-status-never'; ?>">
                            <span class="we-wolt-status-dot"></span>
                            <?php if ($last_xml) : ?>
                                <span><?php _e('Last generated', $this->plugin_name); ?>: <strong><?php echo esc_html($last_xml); ?></strong></span>
                                <?php if ($xml_exists) : ?>
                                    <a href="<?php echo esc_url($wolt_inventory_xml_url_file); ?>" target="_blank" class="we-wolt-file-badge">XML</a>
                                <?php endif; ?>
                                <?php if ($csv_exists) : ?>
                                    <a href="<?php echo esc_url($wolt_inventory_csv_url_file); ?>" target="_blank" download class="we-wolt-file-badge">CSV</a>
                                <?php endif; ?>
                            <?php else : ?>
                                <span><?php _e('Never generated', $this->plugin_name); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="we-wolt-action-btns" style="margin-top:14px;">
                            <button class="button button-primary we-wolt-action-btn has-spinner" type="button" id="wolt-xml-generate"><?php _e('Generate XML', $this->plugin_name); ?><span class="we_spinner"></span></button>
                            <button class="button button-primary we-wolt-action-btn has-spinner" type="button" id="wolt-csv-generate"><?php _e('Generate CSV', $this->plugin_name); ?><span class="we_spinner"></span></button>
                        </div>
                    </div>
                </div>

                </div><!-- /#tab-actions -->

            </form>

        </div>
        <?php
    }

	function webexpert_wolt_tracking_list($column, $the_order) {
		if ( ! is_a( $the_order, 'WC_Order' ) ) {
			global $post;
			$the_order = wc_get_order( $post->ID );
		}

		if ( empty( $the_order ) ) {
			return;
		}

        $is_wolt=null;
        if (strpos($the_order->get_order_key(), 'WOLT-') !== false) {
            $is_wolt=1;
        }

        if ( !empty($is_wolt) && $column == 'order_number' ) {
            echo '<img width=20 src="' . rtrim(plugin_dir_url(__DIR__),'/') . '/assets/wolt.png'.'" style="position: absolute;transform: translate(-12px, -12px);">';
        }
    }

    function webexpert_wolt_inventory_action_scheduler() {
        if ( function_exists( 'as_next_scheduled_action' ) && false === as_next_scheduled_action( 'webexpert_wolt_inventory_update' ) ) {
            as_schedule_recurring_action( time(), 45 * MINUTE_IN_SECONDS, 'webexpert_wolt_inventory_update' );
        }
    }

    function webexpert_wolt_items_action_scheduler() {
        if ( function_exists( 'as_next_scheduled_action' ) && false === as_next_scheduled_action( 'webexpert_wolt_items_update' ) ) {
            as_schedule_recurring_action( time() + 23 * MINUTE_IN_SECONDS, 45 * MINUTE_IN_SECONDS, 'webexpert_wolt_items_update' );
        }
    }

    function inventory_update($product) {
	    $args = [
		    'sku'=>$product->get_sku(),
		    'inventory'=> $this->get_wolt_inventory_quantity( $product )
	    ];
	    return apply_filters( 'webexpert_wolt_inventory_custom_inventory_update_args', $args, $product );
    }

    private function get_wolt_inventory_quantity( $product ) {
        $stock = apply_filters( 'webexpert_wolt_inventory_custom_stock', $product->get_stock_quantity(), $product );

        if ( $stock === null || $stock === '' ) {
            $stock = $product->is_in_stock() ? 999 : 0;
        }

        return max( intval( $stock ), 0 );
    }

	function items_update_variable($product) {
		$variations = $product->get_available_variations( 'objects' );
		$children_data=[];
		foreach ( $variations as $variation ) {
			$variation_sku = $variation->get_sku('edit') ?: $variation->get_id();
			$price=apply_filters('webexpert_wolt_inventory_custom_price',wc_format_decimal($product->get_variation_price()-$variation->get_price(),2),$variation);
			$args = [
				'external_id'=>$variation_sku,
				'enabled'=>$variation->is_in_stock()
			];

            if (!empty($product->get_variation_price()) && $price>0) {
	            $args['price']=round(wc_format_decimal(str_replace(",",".",$price),2)*100);
            }
			$children_data[]=$args;
		}

		return apply_filters( 'webexpert_wolt_inventory_custom_items_update_variable_args', $children_data, $product );
	}

    function items_update($product) {
	    $args = [];
        $rate = 24;

        if (wc_tax_enabled()) {
            $tax_rates = WC_Tax::get_rates( $product->get_tax_class() );
            if ($tax_rates && is_array($tax_rates)) {
                $rate = end($tax_rates)['rate'];
            }
        }

	    if ( $product->is_type( 'variable' ) ) {
		    $regular_price = apply_filters( 'webexpert_wolt_inventory_custom_regular_price', $product->get_variation_regular_price( 'min', false ), $product );
		    $sale_price = apply_filters( 'webexpert_wolt_inventory_custom_sale_price', $product->get_variation_sale_price( 'min', false ), $product );
	    }else {
		    $regular_price = apply_filters( 'webexpert_wolt_inventory_custom_regular_price', $product->get_regular_price(), $product );
		    $sale_price    = apply_filters( 'webexpert_wolt_inventory_custom_sale_price', $product->get_sale_price(), $product );
	    }

        $args = [
            'sku'=>$product->get_sku(),
            'vat_percentage'=>$rate,
            'enabled'=>$product->is_in_stock()
        ];

	    if (get_option('webexpert_wolt_inventory_disable_prices','')!="yes" && $regular_price>0) {
		    $args['price']=round(wc_format_decimal(str_replace(",",".",$regular_price),2)*100);
	        if (!empty($sale_price) && $sale_price<$regular_price) {
		        $args['discounted_price']=floatval(apply_filters('webexpert_wolt_inventory_custom_sale_price',$sale_price,$product))*100;
	        }
	    }

        if (get_option('webexpert_wolt_inventory_disable_images','')!="yes" && !empty($product->get_image_id())) {
            $args['image_url']=apply_filters('webexpert_wolt_inventory_custom_image',wp_get_attachment_image_url($product->get_image_id(),'full'),$product);
        }

        $description = wp_filter_nohtml_kses(
            get_option('webexpert_wolt_inventory_desc_field','short') === 'short'
                ? $product->get_short_description()
                : $product->get_description()
        );
        if (!empty($description)) {
            $args['description'] = $description;
        }

        $custom_sku_option = get_option('webexpert_wolt_inventory_custom_sku','');
        if (!empty($custom_sku_option)) {
            $args['merchant_sku'] = $custom_sku_option === '_sku'
                ? ($product->get_sku() ?: '')
                : ($product->get_meta($custom_sku_option) ?: '');
        }

        $custom_ean_option = get_option('webexpert_wolt_inventory_custom_ean','');
        if (!empty($custom_ean_option)) {
            $args['gtin'] = $custom_ean_option === '_sku'
                ? ($product->get_sku() ?: '')
                : ($product->get_meta($custom_ean_option) ?: $product->get_sku());
        }

        return apply_filters( 'webexpert_wolt_inventory_custom_items_update_args', $args, $product );
    }

    private function queue_product_for_wolt_sync( $product_id ) {
	    if (get_option('webexpert_wolt_inventory_partial_send','yes')=='yes') {
	        $product_ids = get_option('webexpert_wolt_inventory_update_ids',[]);
	        $product_ids[] = $product_id;
	        update_option('webexpert_wolt_inventory_update_ids', array_unique($product_ids), false);

	        $items_ids = get_option('webexpert_wolt_items_update_ids',[]);
	        $items_ids[] = $product_id;
	        update_option('webexpert_wolt_items_update_ids', array_unique($items_ids), false);
	    }
    }

    function on_product_save( $product_id , $product = null) {
        $this->queue_product_for_wolt_sync( $product_id );
    }

    function on_product_stock_change( $product ) {
        if ( ! $product instanceof WC_Product ) {
            return;
        }

        $this->queue_product_for_wolt_sync( $product->get_id() );

        if ( $product->is_type( 'variation' ) && $product->get_parent_id() ) {
            $this->queue_product_for_wolt_sync( $product->get_parent_id() );
        }
    }

    function on_product_stock_status_change( $product_id, $stock_status = '', $product = null ) {
        if ( $product instanceof WC_Product ) {
            $this->on_product_stock_change( $product );
            return;
        }

        $this->queue_product_for_wolt_sync( $product_id );
    }

    public function prepare_args() {
        $args = array('post_type' => 'product', 'posts_per_page' => -1, 'post_status' => 'publish','fields'=>'ids');

        $excluded_terms_categories = get_option('we_wolt_inventory_categories_not_to_list');
        $excluded_terms_tags = get_option('we_wolt_inventory_tags_not_to_list');
        $we_wolt_inventory_attributes = get_option('we_wolt_inventory_attributes_not_to_list');
        if ((is_array($excluded_terms_categories) && sizeof($excluded_terms_categories) > 0) || (is_array($excluded_terms_tags) && sizeof($excluded_terms_tags) > 0) || is_array($we_wolt_inventory_attributes) && sizeof($we_wolt_inventory_attributes) > 0) {
            $args['tax_query'] = array("relation" => "AND");
        }

        if ($excluded_terms_categories > 0) {
            $args['tax_query'][] = array(
                'taxonomy' => 'product_cat',
                'field'    => 'term_id',
                'terms'    => $excluded_terms_categories,
                'operator' => (get_option('we_wolt_inventory_categories_not_to_list_invert',0) ? 'IN' : 'NOT IN')
            );
        }

        if ($excluded_terms_tags > 0) {
            $args['tax_query'][] = array(
                'taxonomy' => 'product_tag',
                'field'    => 'term_id',
                'terms'    => $excluded_terms_tags,
                'operator' => (get_option('we_wolt_inventory_tags_not_to_list_invert',0) ? 'IN' : 'NOT IN')
            );
        }

        if ($we_wolt_inventory_attributes) {
            $temp_attributes=[];
            if (sizeof($we_wolt_inventory_attributes)>1) {
                $temp_attributes['relation']=(get_option('we_wolt_inventory_attributes_not_to_list_invert',0) ? 'OR' : 'AND');
            }
            foreach ($we_wolt_inventory_attributes as $attribute_filter) {
                $expl = explode("__", $attribute_filter);
                $temp_attributes[] = array(
                    'taxonomy' => $expl[1],
                    'field'    => 'term_id',
                    'terms'    => $expl[0],
                    'operator' => (get_option('we_wolt_inventory_attributes_not_to_list_invert',0) ? 'IN' : 'NOT IN')
                );
            }
            $args['tax_query'][]=$temp_attributes;
        }

        $hide_custom_ids=apply_filters('webexpert_wolt_inventory_hide_certain_product_ids',[]);
        if (!empty($hide_custom_ids)) {
            $args['post__not_in']=$hide_custom_ids;
        }

        return apply_filters( 'webexpert_wolt_inventory_custom_args', $args);
    }

    function webexpert_wolt_inventory_as_items_update() {
        $assemble['data'] = [];
        if (get_option('webexpert_wolt_inventory_partial_send','yes')=='yes') {

            if (empty(get_option('webexpert_wolt_items_update_ids', []))) {
                return;
            }

            $assembled=[];
            foreach (get_option('webexpert_wolt_items_update_ids', []) as $item) {
                $product=wc_get_product($item);
                if ($product && !isset($assembled[$product->get_sku()])) {
                    $item_update = $this->items_update($product);
                    if (!empty($item_update)) {
	                    $assemble['data'][] = $item_update;
	                    if ($product->is_type('variable')) {
		                    if ( get_option( 'webexpert_wolt_inventory_variations_on_item_update', 'no' ) == "yes" ) {
			                    $variations = $product->get_available_variations( 'objects' );
			                    foreach ( $variations as $variation ) {
				                    $variation_sku = $variation->get_sku('edit') ?: $variation->get_id();
				                    $item_update_variation = $this->items_update($variation);
				                    if (!empty($item_update_variation)) {
					                    $assemble['data'][] = $item_update_variation;
					                    $assembled[ $variation_sku ] = 1;
				                    }
			                    }
		                    }
	                    }
	                    $assembled[$product->get_sku()]=1;
                    }
                }
            }
        }else {
            $posts=get_posts($this->prepare_args());
            if (empty($posts)) {
                return;
            }

            $assembled=[];
            foreach ($posts as $post_id) {
                $product=wc_get_product($post_id);
                if ($product && !isset($assembled[$product->get_sku()])) {
	                $item_update = $this->items_update($product);
	                if (!empty($item_update)) {
		                $assemble['data'][] = $item_update;
		                if ( $product->is_type( 'variable' ) ) {
			                if ( get_option( 'webexpert_wolt_inventory_variations_on_item_update', 'no' ) == "yes" ) {
				                $variations = $product->get_available_variations( 'objects' );
				                foreach ( $variations as $variation ) {
					                $variation_sku = $variation->get_sku('edit') ?: $variation->get_id();
					                $item_update_variation = $this->items_update($variation);
                                    if (!empty($item_update_variation)) {
	                                    $assemble['data'][] = $item_update_variation;
	                                    $assembled[ $variation_sku ] = 1;
                                    }
				                }
			                }
		                }
		                $assembled[ $product->get_sku() ] = 1;
	                }
                }
            }
        }

        $result = $this->send_wolt_payload_to_venues( 'venues/%s/items', $assemble, 'wolt-items-update' );

        if ( is_wp_error( $result ) ) {
            error_log( 'Wolt itemUpdate error: ' . $result->get_error_message() );
        }else {
            if (get_option('webexpert_wolt_inventory_partial_send','yes')=='yes') {
                update_option('webexpert_wolt_items_update_ids',[],false);
            }
            update_option('webexpert_wolt_inventory_last_items_update',date_i18n('d/m/Y H:i:s'));
        }
    }


    function webexpert_wolt_inventory_as_inventory_update() {
        $assembleInventory['data'] = [];
        if (get_option('webexpert_wolt_inventory_partial_send','yes')=='yes') {

            if (empty(get_option('webexpert_wolt_inventory_update_ids', []))) {
                return;
            }

            $assembled=[];
            foreach (get_option('webexpert_wolt_inventory_update_ids', []) as $item) {
                $product=wc_get_product($item);
                if ($product) {
	                if (($product->is_type('simple') || $product->is_type('variation')) && $product->get_sku() && !isset($assembled[$product->get_sku()])) {
		                $assembleInventory['data'][] = $this->inventory_update($product);
		                $assembled[$product->get_sku()]=1;
                    }
                }
            }
        }else {
            $posts=get_posts($this->prepare_args());
            if (empty($posts)) {
                return;
            }

            $assembled=[];
            foreach ($posts as $post_id) {
                $product=wc_get_product($post_id);
	            if ($product) {
		            if ($product->is_type('simple') && !isset($assembled[$product->get_sku()])) {
			            $assembleInventory['data'][] = $this->inventory_update($product);
			            $assembled[$product->get_sku()]=1;
		            }
	            }
            }
        }

        $result = $this->send_wolt_payload_to_venues( 'venues/%s/items/inventory', $assembleInventory, 'wolt-inventory-update' );

        if ( is_wp_error( $result ) ) {
            error_log( 'Wolt inventoryUpdate error: ' . $result->get_error_message() );
        }else {
            if (get_option('webexpert_wolt_inventory_partial_send','yes')=='yes') {
                update_option('webexpert_wolt_inventory_update_ids',[],false);
            }
            update_option('webexpert_wolt_inventory_last_update',date_i18n('d/m/Y H:i:s'));
        }
    }

    function generate_csv() {
        $this->ensure_admin_ajax_permission();

        $posts=get_posts($this->prepare_args());
        if (empty($posts)) {
            wp_send_json_error( __( 'No products found.', $this->plugin_name ) );
        }

        $upload_dir = wp_upload_dir();
        $wolt_inventory_csv_dir = $upload_dir['basedir'] . '/pixelskit-wolt';
        $wolt_inventory_csv_dir_file = $wolt_inventory_csv_dir .'/products.csv';
        $wolt_inventory_csv_url_file = $upload_dir['baseurl'] . '/pixelskit-wolt/products.csv';
        wp_mkdir_p($wolt_inventory_csv_dir);
        $file = fopen($wolt_inventory_csv_dir_file,"w");

	    $headers=['name','sku','description','regular_price','sale_price','image_url','category','subcategory'];
        $vat_enabled = (get_option('woocommerce_calc_taxes') === 'yes');

        if ($vat_enabled) {
            $pos = array_search('description', $headers);
            if ($pos !== false) {
                array_splice($headers, $pos + 1, 0, 'vat');
            }
        }

	    $custom_ean_option = get_option('webexpert_wolt_inventory_custom_ean','');

	    if (!empty($custom_ean_option)) {
		    $position = array_search('sku', $headers);
		    if ($position !== false) {
			    array_splice($headers, $position + 1, 0, 'barcode');
		    }
	    }

        if (!empty(get_option('webexpert_wolt_inventory_size',[]))) {
	        $position = array_search('description', $headers);
	        if ($position !== false) {
		        array_splice($headers, $position, 0, 'size');
	        }
        }

        $desc_field   = get_option('webexpert_wolt_inventory_desc_field','short');
        $size_option  = get_option('webexpert_wolt_inventory_size',[]);
        $base_country = $vat_enabled ? WC()->countries->get_base_country() : '';
        $base_state   = $vat_enabled ? WC()->countries->get_base_state() : '';
        $vat_cache    = [];

        fputcsv($file, $headers,';');
        foreach ($posts as $post_id) {
            $csv_row=[];
            $product=wc_get_product($post_id);
            if ($product) {
	            if (!apply_filters('webexpert_wolt_inventory_visibility_control',true,$product)) {
		            continue;
	            }

                $description=wp_filter_nohtml_kses($desc_field=='short' ? $product->get_short_description() : $product->get_description());
	            $csv_row['name']=apply_filters('webexpert_wolt_inventory_custom_name',$product->get_name(),$product);
                $csv_row['sku']=$product->get_sku();
	            if (!empty($custom_ean_option)) {
		            $csv_row['barcode']=!empty($product->get_meta($custom_ean_option)) ? $product->get_meta($custom_ean_option) : '';
                }
	            if (!empty($size_option)) {
		            $csv_row['size']='';
                }
                $csv_row['description']=esc_html($description);
                if ($vat_enabled) {
                    $tax_class = $product->get_tax_class();
                    if (!isset($vat_cache[$tax_class])) {
                        $rates = WC_Tax::find_rates(['country'=>$base_country,'state'=>$base_state,'postcode'=>'','city'=>'','tax_class'=>$tax_class]);
                        $first = !empty($rates) ? reset($rates) : [];
                        $vat_cache[$tax_class] = isset($first['rate']) ? floatval($first['rate']) : 0;
                    }
                    $csv_row['vat'] = $vat_cache[$tax_class];
                }
	            $csv_row['regular_price']=apply_filters('webexpert_wolt_inventory_custom_regular_price', ($product->is_type('variable') ? $product->get_variation_regular_price( 'min' ) : $product->get_regular_price()),$product);
	            $csv_row['sale_price']=apply_filters('webexpert_wolt_inventory_custom_sale_price', ($product->is_type('variable') ? $product->get_variation_sale_price( 'min' ) : $product->get_sale_price()),$product);
                $csv_row['image_url']=apply_filters('webexpert_wolt_inventory_custom_image',wp_get_attachment_image_url($product->get_image_id(),'full'),$product);

                $categories_list = get_the_terms(($product->is_type('variation') ? $product->get_parent_id() : $product->get_id()), 'product_cat');
                if ($categories_list) {
                    $parent = null;
                    $last_category = end($categories_list);

                    $categories_list = array();
                    $ancestors = get_ancestors($last_category->term_id, 'product_cat', 'taxonomy');
                    $ancestors=array_reverse($ancestors);
                    foreach ($ancestors as $parent) {
                        $term = get_term_by('id', $parent, 'product_cat');
                        $categories_list[] = $term->name;
                    }
                    $categories_list[] = $last_category->name;

                    if (sizeof($categories_list)>2) {
                        list($array1, $array2) = array_chunk($categories_list, ceil(count($categories_list) / 2));
                        $csv_row['category']=implode(" ",$array1);
                        $csv_row['subcategory']=implode(" ",$array2);
                    }else {
                        if (!empty($categories_list[0])) {
                            $csv_row['category']=$categories_list[0];
                        }
                        if (!empty($categories_list[1])) {
                            $csv_row['subcategory']=$categories_list[1];
                        }
                    }
                }

	            fputcsv($file, $csv_row,';');
	            if ($product->is_type('variable')) {
		            $variations = $product->get_available_variations( 'objects' );
		            foreach ( $variations as $variation ) {
			            $variation_sku = $variation->get_sku('edit') ?: $variation->get_id();
			            $csv_sub_row=[];
			            $csv_sub_row['name']='';
			            $csv_sub_row['sku']=$variation_sku;
			            if (!empty($size_option)) {
                            $total_sizes=[];
				            foreach ($size_option as $size) {
					            if ($variation->get_attribute($size)) {
						            $clean_size = apply_filters('webexpert_custom_size_replace',$variation->get_attribute($size),$variation);
						            if (!in_array($clean_size, $total_sizes)) {
							            $total_sizes[] = $clean_size;
						            }
					            }
				            }
				            $csv_sub_row['size']=!empty($total_sizes) ? implode(",",$total_sizes) : '';
			            }
			            $csv_sub_row['description']='';
                        if ($vat_enabled) {
                            $tax_class = $variation->get_tax_class();
                            if (!isset($vat_cache[$tax_class])) {
                                $rates = WC_Tax::find_rates(['country'=>$base_country,'state'=>$base_state,'postcode'=>'','city'=>'','tax_class'=>$tax_class]);
                                $first = !empty($rates) ? reset($rates) : [];
                                $vat_cache[$tax_class] = isset($first['rate']) ? floatval($first['rate']) : 0;
                            }
                            $csv_sub_row['vat'] = $vat_cache[$tax_class];
                        }
			            $csv_sub_row['regular_price']=apply_filters('webexpert_wolt_inventory_custom_regular_price',$variation->get_regular_price(),$variation);
			            $csv_sub_row['sale_price']=apply_filters('webexpert_wolt_inventory_custom_sale_price',$variation->get_sale_price(),$variation);
			            $csv_sub_row['image_url']=apply_filters('webexpert_wolt_inventory_custom_image',wp_get_attachment_image_url($variation->get_image_id(),'full'),$variation);
			            $csv_sub_row['category']='';
			            $csv_sub_row['subcategory']='';
			            fputcsv($file, $csv_sub_row,';');
		            }
	            }
            }
        }

        fclose($file);
        update_option('webexpert_wolt_inventory_generate_xml',date_i18n('d/m/Y H:i:s'));
        wp_send_json_success(['url'=>$wolt_inventory_csv_url_file]);
    }

    function generate_xml() {
        $this->ensure_admin_ajax_permission();

        $posts=get_posts($this->prepare_args());
        if (empty($posts)) {
            wp_send_json_error( __( 'No products found.', $this->plugin_name ) );
        }

        $upload_dir = wp_upload_dir();
        $wolt_inventory_xml_dir = $upload_dir['basedir'] . '/pixelskit-wolt';
        $wolt_inventory_xml_dir_file = $wolt_inventory_xml_dir .'/products.xml';
        $wolt_inventory_xml_url_file = $upload_dir['baseurl'] . '/pixelskit-wolt/products.xml';
        wp_mkdir_p($wolt_inventory_xml_dir);

        $xml_writer = new XMLWriter();
        $xml_writer->openUri($wolt_inventory_xml_dir_file);
        $xml_writer->startDocument('1.0', 'UTF-8');
        $xml_writer->startElement('wolt');
        $xml_writer->writeElement('created_at',date_i18n("Y-m-d H:i:s"));
        $xml_writer->startElement('products');

        $vat_enabled       = (get_option('woocommerce_calc_taxes') === 'yes');
        $custom_sku_option = get_option('webexpert_wolt_inventory_custom_sku','');
        $custom_ean_option = get_option('webexpert_wolt_inventory_custom_ean','');
        $desc_field        = get_option('webexpert_wolt_inventory_desc_field','short');
        $size_option       = get_option('webexpert_wolt_inventory_size',[]);
        $base_country      = $vat_enabled ? WC()->countries->get_base_country() : '';
        $base_state        = $vat_enabled ? WC()->countries->get_base_state() : '';
        $vat_cache         = [];

        foreach ($posts as $post_id) {
            $product=wc_get_product($post_id);
            if (!$product) {
                continue;
            }

	        if (!apply_filters('webexpert_wolt_inventory_visibility_control',true,$product)) {
		        continue;
	        }

	        $xml_writer->startElement('product');
                $description=wp_filter_nohtml_kses($desc_field=='short' ? $product->get_short_description() : $product->get_description());

	            $custom_sku=null;
	            if (!empty($custom_sku_option)) {
		            $custom_sku = $custom_sku_option === '_sku'
                        ? ($product->get_sku() ?: '')
                        : ($product->get_meta($custom_sku_option) ?: '');
	            }

	            $custom_ean=null;
	            if (!empty($custom_ean_option)) {
		            $custom_ean = $custom_ean_option === '_sku'
                        ? ($product->get_sku() ?: '')
                        : ($product->get_meta($custom_ean_option) ?: $product->get_sku());
	            }

	            $xml_writer->writeElement('name',apply_filters('webexpert_wolt_inventory_custom_name',$product->get_name(),$product));
                $xml_writer->writeElement('sku',$custom_sku);
                if (!empty($custom_ean)) {
	                $xml_writer->writeElement('ean',$custom_ean);
                }

                if (!empty($description)) {
                    $xml_writer->startElement('description');
                    $xml_writer->writeCData(esc_html($description));
                    $xml_writer->endElement();
                }

                if ($vat_enabled) {
                    $tax_class = $product->get_tax_class();
                    if (!isset($vat_cache[$tax_class])) {
                        $rates = WC_Tax::find_rates(['country'=>$base_country,'state'=>$base_state,'postcode'=>'','city'=>'','tax_class'=>$tax_class]);
                        $first = !empty($rates) ? reset($rates) : [];
                        $vat_cache[$tax_class] = isset($first['rate']) ? floatval($first['rate']) : 0;
                    }
                    $xml_writer->writeElement('vat',$vat_cache[$tax_class]);
                }

                $xml_writer->writeElement('regular_price',apply_filters('webexpert_wolt_inventory_custom_regular_price',$product->get_regular_price(),$product));
                if ($product->get_regular_price()>$product->get_sale_price()) {
                    $sale_price = apply_filters('webexpert_wolt_inventory_custom_sale_price',$product->get_sale_price(),$product);
                    if (!empty($sale_price)) {
                        $xml_writer->writeElement('sale_price',$sale_price);
                    }
                }

                $image_url = apply_filters('webexpert_wolt_inventory_custom_image',wp_get_attachment_image_url($product->get_image_id(),'full'),$product);
                if (!empty($image_url)) {
                    $xml_writer->writeElement('image_url',$image_url);
                }

	            $stock = apply_filters('webexpert_wolt_inventory_custom_stock',$product->get_stock_quantity(),$product);
	            if (intval($stock))
		            $xml_writer->writeElement("quantity",$stock);

                $categories_list = get_the_terms(($product->is_type('variation') ? $product->get_parent_id() : $product->get_id()), 'product_cat');
                if ($categories_list) {
                    $parent = null;
                    $last_category = end($categories_list);

                    $categories_list = array();
                    $ancestors = get_ancestors($last_category->term_id, 'product_cat', 'taxonomy');
                    $ancestors=array_reverse($ancestors);
                    foreach ($ancestors as $parent) {
                        $term = get_term_by('id', $parent, 'product_cat');
                        $categories_list[] = $term->name;
                    }
                    $categories_list[] = $last_category->name;

                    if (sizeof($categories_list)>2) {
                        list($array1, $array2) = array_chunk($categories_list, ceil(count($categories_list) / 2));
                        $xml_writer->writeElement('category',implode(" ",$array1));
                        $xml_writer->writeElement('subcategory',implode(" ",$array2));
                    }else {
                        if (!empty($categories_list[0])) {
                            $xml_writer->writeElement('category',$categories_list[0]);
                        }
                        if (!empty($categories_list[1])) {
                            $xml_writer->writeElement('subcategory',$categories_list[1]);
                        }
                    }
                }

                if ($product->is_type('variable')) {
	                $xml_writer->startElement('variations');
	                $variations = $product->get_available_variations('objects');
                    foreach ($variations as $variation) {
                        $variation_sku = $variation->get_sku('edit') ?: $variation->get_id();
	                    $xml_writer->startElement('variation');
	                    $xml_writer->writeElement('sku',$variation_sku);
	                    if (!empty($size_option)) {
		                    $total_sizes=[];
		                    foreach ($size_option as $size) {
			                    if ($variation->get_attribute($size)) {
				                    $clean_size = apply_filters('webexpert_custom_size_replace',$variation->get_attribute($size),$variation);
				                    if (!in_array($clean_size, $total_sizes)) {
					                    $total_sizes[] = $clean_size;
				                    }
			                    }
		                    }
		                    $xml_writer->writeElement("size",!empty($total_sizes) ? implode(",",$total_sizes) : '');
	                    }

                        if ($vat_enabled) {
                            $tax_class = $variation->get_tax_class();
                            if (!isset($vat_cache[$tax_class])) {
                                $rates = WC_Tax::find_rates(['country'=>$base_country,'state'=>$base_state,'postcode'=>'','city'=>'','tax_class'=>$tax_class]);
                                $first = !empty($rates) ? reset($rates) : [];
                                $vat_cache[$tax_class] = isset($first['rate']) ? floatval($first['rate']) : 0;
                            }
                            $xml_writer->writeElement('vat',$vat_cache[$tax_class]);
                        }

	                    $xml_writer->writeElement('regular_price',apply_filters('webexpert_wolt_inventory_custom_regular_price',$variation->get_regular_price(),$variation));
	                    if ($variation->get_regular_price()>$variation->get_sale_price()) {
		                    $var_sale = apply_filters('webexpert_wolt_inventory_custom_sale_price',$variation->get_sale_price(),$variation);
		                    if (!empty($var_sale)) {
			                    $xml_writer->writeElement('sale_price',$var_sale);
		                    }
	                    }
	                    $var_image = apply_filters('webexpert_wolt_inventory_custom_image',wp_get_attachment_image_url($variation->get_image_id(),'full'),$variation);
	                    if (!empty($var_image)) {
		                    $xml_writer->writeElement('image_url',$var_image);
	                    }

	                    $stock = apply_filters('webexpert_wolt_inventory_custom_stock',$variation->get_stock_quantity(),$variation);
                        if (intval($stock))
	                        $xml_writer->writeElement("quantity",$stock);

	                    $xml_writer->endElement();
                    }
	                $xml_writer->endElement();
                }
	        $xml_writer->endElement();
        }
        $xml_writer->endElement();
        $xml_writer->endElement();
        $xml_writer->flush();

        if (file_exists($wolt_inventory_xml_dir_file) && filesize($wolt_inventory_xml_dir_file) > 0) {
            update_option('webexpert_wolt_inventory_generate_xml',date_i18n('d/m/Y H:i:s'));
            wp_send_json_success(['url'=>$wolt_inventory_xml_url_file]);
        }else {
            wp_send_json_error();
        }
    }

    function fetch_order_ajax() {
        $this->ensure_admin_ajax_permission();

        $order_id = isset( $_POST['order_id'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['order_id'] ) ) ) : '';
        if ( empty( $order_id ) ) {
            wp_send_json_error( __( 'Order ID is required.', $this->plugin_name ) );
        }

        $wolt_order = $this->fetch_wolt_order( $order_id );
        if ( is_wp_error( $wolt_order ) ) {
            wp_send_json_error( $wolt_order->get_error_message() );
        }

        $this->create_wolt_order($wolt_order);
    }

    function create_wolt_order($wolt_order) {
	    $args = array(
		    'limit' => 1,
		    'orderby' => 'date',
		    'order' => 'DESC',
		    'meta_key' => '_wolt_order_id',
		    'meta_value' => $wolt_order->id,
		    'meta_compare' => '='
	    );

	    $query = new WC_Order_Query($args);
	    $orders = $query->get_orders();
        $order_exists = ! empty( $orders );

	    if ($order_exists) {
		    $order = reset($orders);
	    } else {
		    $order=new WC_Order();
	    }

        try {
	        $order->update_meta_data('_wolt_order_number', $wolt_order->order_number);
	        $order->update_meta_data('_wolt_order_id', $wolt_order->id);
            $wolt_venue_id = $this->get_wolt_order_venue_id( $wolt_order );
            if ( ! empty( $wolt_venue_id ) ) {
                $order->update_meta_data( '_wolt_venue_id', $wolt_venue_id );
            }
            $order->set_created_via( 'wolt_inventory' );
            $order->set_prices_include_tax( 'yes' === get_option( 'woocommerce_prices_include_tax' ) );
            $order->set_currency( get_woocommerce_currency() );
            $order->set_customer_note( $wolt_order->consumer_comment ?? '' );

            $name_parts = preg_split( '/\s+/', trim( (string) ( $wolt_order->consumer_name ?? '' ) ), 2 );
            $first_name = isset( $name_parts[0] ) ? $name_parts[0] : '';
            $last_name  = isset( $name_parts[1] ) ? $name_parts[1] : '';
            $order->set_billing_first_name($first_name);
            $order->set_customer_id(0);
            $order->set_billing_last_name($last_name);
	        $order->set_billing_email("{$wolt_order->id}@wolt.com");
	        $order->set_payment_method("wolt_inventory");
            if (in_array($wolt_order->order_status,["created"])) {
                $order->set_status("on-hold");
            }elseif (in_array($wolt_order->order_status,["production"])) {
                $order->set_status(apply_filters("webexpert_wolt_inventory_custom_processing_status","processing",$order));
            }elseif (in_array($wolt_order->order_status,["ready","delivered"])) {
                $order->set_status("completed");
            }elseif (in_array($wolt_order->order_status,["canceled"])) {
                $order->set_status("cancelled");
            }

	        if (!$order_exists) {
		        foreach ( $wolt_order->items as $line_item ) {
                    $product_id = apply_filters( 'webexpert_wolt_inventory_resolve_product_id', null, $line_item, $wolt_order );
                    if ( ! $product_id ) {
                        $custom_sku_option = get_option( 'webexpert_wolt_inventory_custom_sku', '' );

                        if ( empty( $custom_sku_option ) || $custom_sku_option === '_sku' ) {
                            // Default: match by WooCommerce SKU
                            $product_id = wc_get_product_id_by_sku( $line_item->sku );

                        } elseif ( $custom_sku_option === '_global_unique_id' ) {
                            // global_unique_id is a first-class WC property (get_global_unique_id()).
                            // It may live in the wc_products custom table (HPOS) rather than post meta,
                            // so we use WC_Product_Query with a hooked query arg instead of a raw meta_query.
                            add_filter( 'woocommerce_product_data_store_cpt_get_products_query',
                                static function ( $query, $query_vars ) {
                                    if ( ! empty( $query_vars['_global_unique_id'] ) ) {
                                        $query['meta_query'][] = [
                                            'key'   => '_global_unique_id',
                                            'value' => $query_vars['_global_unique_id'],
                                        ];
                                    }
                                    return $query;
                                }, 10, 2
                            );

                            $results    = wc_get_products( [
                                'limit'             => 1,
                                'status'            => 'publish',
                                'return'            => 'ids',
                                '_global_unique_id' => $line_item->sku,
                            ] );
                            $product_id = ! empty( $results ) ? (int) $results[0] : 0;
                        } else {
                            $posts = get_posts( [
                                'post_type'   => [ 'product', 'product_variation' ],
                                'post_status' => 'publish',
                                'numberposts' => 1,
                                'fields'      => 'ids',
                                'meta_query'  => [ [
                                    'key'   => $custom_sku_option,
                                    'value' => $line_item->sku,
                                ] ],
                            ] );
                            $product_id = ! empty( $posts ) ? (int) $posts[0] : 0;
                        }
                    }

			        if ( $product_id ) {
				        $product = wc_get_product( $product_id );
				        if ( $product ) {
					        $item_already_added = false;
					        foreach ( $order->get_items() as $order_item ) {
						        if ( $order_item->get_meta( 'item_id' ) == $line_item->id ) {
							        $item_already_added = true;
							        break;
						        }
					        }

					        if ( !$item_already_added ) {
                                $qty = $line_item->count;
                                if (!empty($line_item->weight_details) && !empty($line_item->weight_details->weight_in_grams)) {
                                    $qty = wc_get_weight($line_item->weight_details->weight_in_grams, get_option( 'woocommerce_weight_unit' ), 'g');
                                }

						        $args = array(
							        'name' => $line_item->name,
							        'subtotal' => wc_get_price_excluding_tax($product, [
								        'price' => $line_item->unit_price->amount / 100,
                                        'qty' => $qty
							        ]),
							        'total' => wc_get_price_excluding_tax($product, [
								        'price' => $line_item->unit_price->amount / 100,
                                        'qty' => $qty
							        ]),
							        'quantity' => $qty,
						        );

						        $line_item_id = $order->add_product( $product, $qty, $args );

						        $order_item = $order->get_item( $line_item_id );
						        if ( $order_item instanceof WC_Order_Item_Product ) {
							        $order_item->add_meta_data( 'item_id', $line_item->id, true );
							        $order_item->save();
						        }
					        }
				        }
			        }
		        }
	        }

            $order->set_date_created(strtotime($wolt_order->created_at));
            $order->set_date_modified(strtotime($wolt_order->modified_at));
            $order->calculate_totals();
            $order->set_order_key("WOLT-{$wolt_order->id}");

            if (!empty($wolt_order->company_tax_id)) {
                $order->update_meta_data( apply_filters('webexpert_wolt_inventory_invoice_toggle','_billing_invoice'), apply_filters('webexpert_wolt_inventory_invoice_value_toggle','y'));
                $order->update_meta_data( apply_filters('webexpert_wolt_inventory_billing_vat_id','_billing_vat_id'), $wolt_order->company_tax_id);
                $order->set_billing_company($wolt_order->company_name);
            }else {
                $order->update_meta_data( apply_filters('webexpert_wolt_inventory_invoice_toggle','_billing_invoice'), 'n');
            }
	        $order_id=$order->save();
	        if ($order_id) {
		        do_action( 'webexpert_wolt_inventory_order_inserted', $order_id );
		        wp_send_json_success(['order_id'=>$order->get_id()]);
	        }
        }catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    function wolt_orders_callback() {
        $body = file_get_contents('php://input');
        $response = json_decode($body);

	    $logger = wc_get_logger();
	    $logger->info( wc_print_r( json_encode($response,JSON_UNESCAPED_UNICODE), true ), array( 'source' => 'wolt-orders' ) );

        if ( empty( $response ) || empty( $response->type ) ) {
            wp_send_json_error( __( 'Invalid Wolt webhook payload.', $this->plugin_name ), 400 );
        }

        if ($response->type=='order.notification') {
            if (!empty($response->order->id)) {
                $wolt_order = $this->fetch_wolt_order( $response->order->id );
                if ( is_wp_error( $wolt_order ) ) {
                    wp_send_json_error( $wolt_order->get_error_message() );
                }

                $this->create_wolt_order($wolt_order);
            }
        } elseif ( in_array( $response->type, ['order.status_update', 'order.cancelled'], true ) ) {
            if ( ! empty( $response->order->id ) ) {
                $wolt_order = $this->fetch_wolt_order( $response->order->id );
                if ( is_wp_error( $wolt_order ) ) {
                    wp_send_json_error( $wolt_order->get_error_message() );
                }

                $this->create_wolt_order($wolt_order);
            }
        }

        wp_send_json_success();
    }

    function register_wolt_orders_webhook() {
        register_rest_route( 'wc/v3', 'wolt_orders', array(
            'methods' => 'POST',
            'callback' => array($this,'wolt_orders_callback'),
            'permission_callback' => '__return_true'
        ));
    }

    function force_inventory_update() {
        $this->ensure_admin_ajax_permission();

        $assembleInventory['data'] = [];
        $posts=get_posts($this->prepare_args());
        if (empty($posts)) {
            wp_send_json_error( __( 'No products found.', $this->plugin_name ) );
        }

        $assembled=[];
        foreach ($posts as $post_id) {
            $product=wc_get_product($post_id);
	        if ($product) {
		        if ($product->is_type('simple') && !isset($assembled[$product->get_sku()])) {
			        $assembleInventory['data'][] = $this->inventory_update($product);
			        $assembled[$product->get_sku()]=1;
		        }
	        }
        }

        $result = $this->send_wolt_payload_to_venues( 'venues/%s/items/inventory', $assembleInventory, 'wolt-inventory-update' );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }else {
            if (get_option('webexpert_wolt_inventory_partial_send','yes')=='yes') {
                update_option('webexpert_wolt_inventory_update_ids',[],false);
            }
            update_option('webexpert_wolt_inventory_last_update',date_i18n('d/m/Y H:i:s'));
            wp_send_json_success( sprintf( '%s (%d venues)', date_i18n('d/m/Y H:i:s'), count( $result ) ) );
        }
    }

    function force_item_update() {
        $this->ensure_admin_ajax_permission();

        $assemble['data'] = [];
        $posts=get_posts($this->prepare_args());
        if (empty($posts)) {
            wp_send_json_error( __( 'No products found.', $this->plugin_name ) );
        }

        $assembled=[];
	    $assembled_variable=[];
        foreach ($posts as $post_id) {
            $product=wc_get_product($post_id);
	        if ($product) {
		        if (!isset($assembled[$product->get_sku()])) {
			        $item_update = $this->items_update($product);
                    if (!empty($item_update)) {
	                    $assemble['data'][] = $item_update;
                    }
		        }
                if ($product->is_type('variable')) {
	                if (get_option('webexpert_wolt_inventory_variations_on_item_update','no')=="yes") {
		                $variations = $product->get_available_variations( 'objects' );
		                foreach ( $variations as $variation ) {
			                $variation_sku = $variation->get_sku('edit') ?: $variation->get_id();
			                $item_update_variation = $this->items_update($variation);
                            if (!empty($item_update_variation)) {
	                            $assemble['data'][] = $item_update_variation;
	                            $assembled[$variation_sku]=1;
                            }
		                }
	                }
	                $assembled_variable=array_merge($this->items_update_variable($product),$assembled_variable);
                }
		        $assembled[$product->get_sku()]=1;
	        }
        }

        $venue_ids = $this->get_wolt_venue_ids();
        if ( empty( $venue_ids ) ) {
            wp_send_json_error( __( 'No Wolt venue IDs configured.', $this->plugin_name ) );
        }

        $errors = [];
        foreach ( $venue_ids as $venue_id ) {
            $venue_assemble = $assemble;
            $disabled_items = $this->get_wolt_menu_disabled_items( $venue_id, $assembled );
            if ( is_wp_error( $disabled_items ) ) {
                $errors[] = $disabled_items->get_error_message();
                continue;
            }

            foreach ( $disabled_items as $disabled_item ) {
                $venue_assemble['data'][] = $disabled_item;
            }

            $this->log_wolt_payload( 'wolt-items-update', $venue_assemble, $venue_id );
            $request = $this->wolt_pos_request( $venue_id, 'venues/' . rawurlencode( $venue_id ) . '/items', 'PATCH', $venue_assemble );
            if ( is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) !== 202 ) {
                $errors[] = $this->format_wolt_response_error( $venue_id, $request );
                continue;
            }

            if ( ! empty( $assembled_variable ) ) {
                $options_payload = [ 'data' => $assembled_variable ];
                $this->log_wolt_payload( 'wolt-items-variable-update', $options_payload, $venue_id );
                $request = $this->wolt_pos_request( $venue_id, 'venues/' . rawurlencode( $venue_id ) . '/options/values', 'PATCH', $options_payload );
                if ( is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) !== 202 ) {
                    $errors[] = $this->format_wolt_response_error( $venue_id, $request );
                }
            }
        }

        if ( ! empty( $errors ) ) {
            wp_send_json_error( implode( "\n", $errors ) );
        }

        update_option('webexpert_wolt_inventory_last_items_update',date_i18n('d/m/Y H:i:s'));
        wp_send_json_success( sprintf( '%s (%d venues)', date_i18n('d/m/Y H:i:s'), count( $venue_ids ) ) );
    }

    function plugin_action_links($links, $file)
    {
        static $this_plugin;
        if (!$this_plugin) {
            $this_plugin = ( dirname(plugin_basename(__FILE__), 2) . '/' . $this->plugin_name . '.php' );
        }
        if ($file == $this_plugin) {
            $settings_link = '<a href="' . admin_url("admin.php?page=pixelskit-wolt").'">'.__('Settings', $this->plugin_name).'</a>';
            array_unshift($links, $settings_link);
        }
        return $links;
    }

	function disable_wolt_emails( $recipient, $object ) {
		if ($object instanceof WC_Order && $object->get_created_via() == "wolt_inventory") {
			$recipient = '';
		}
		return $recipient;
    }

    function redirect_mails($args){
	    if (is_array($args['to'])) {
		    $args['to'] = array_filter($args['to'], function($email) {
			    $domain_name = substr(strrchr($email, "@"), 1);
			    return $domain_name !== "wolt.com";
		    });
	    } else {
		    $domain_name = substr(strrchr($args['to'], "@"), 1);
		    if ($domain_name === "wolt.com") {
			    $args['to'] = '';
		    }
	    }
        return $args;
    }

	function add_my_gateway_class( $methods ) {
		$methods[] = 'WC_Wolt_Inventory_Gateway';
		return $methods;
	}

	function woocommerce_shop_order_search_order_key( $search_fields ) {
		$search_fields[] = '_order_key';
		return $search_fields;
	}

	// --- Unified marketplace order filter ---

	function webexpert_marketplace_add_filter_option( $options ) {
		$options['wolt_inventory'] = 'pixelskit-wolt';
		return $options;
	}

	function webexpert_render_marketplace_order_filter() {
		global $typenow, $webexpert_marketplace_filter_rendered;
		if ( isset( $typenow ) && $typenow && $typenow !== 'shop_order' ) return;
		if ( ! empty( $webexpert_marketplace_filter_rendered ) ) return;
		$webexpert_marketplace_filter_rendered = true;
		$options = apply_filters( 'webexpert_marketplace_order_filter_options', [] );
		if ( empty( $options ) ) return;
		$selected = isset( $_GET['webexpert_marketplace_filter'] ) ? sanitize_text_field( $_GET['webexpert_marketplace_filter'] ) : '';
		echo '<select name="webexpert_marketplace_filter" id="webexpert_marketplace_filter">';
		echo '<option value="">' . esc_html__( 'All marketplaces' ) . '</option>';
		foreach ( $options as $value => $label ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $value ), selected( $selected, $value, false ), esc_html( $label ) );
		}
		echo '</select>';
	}

	function webexpert_apply_marketplace_filter_cpt( $query ) {
		if ( ! $query->is_main_query() ) return $query;
		$filter   = isset( $_GET['webexpert_marketplace_filter'] ) ? sanitize_text_field( $_GET['webexpert_marketplace_filter'] ) : '';
		$posttype = isset( $_GET['post_type'] ) ? sanitize_text_field( $_GET['post_type'] ) : '';
		if ( ! $filter || $posttype !== 'shop_order' ) return $query;
		$options = apply_filters( 'webexpert_marketplace_order_filter_options', [] );
		if ( ! array_key_exists( $filter, $options ) ) return $query;
		$meta_query   = (array) $query->get( 'meta_query' );
		$meta_query[] = [ 'key' => '_created_via', 'value' => $filter, 'compare' => '=' ];
		$query->set( 'meta_query', $meta_query );
		return $query;
	}

	function webexpert_apply_marketplace_filter_hpos( $args ) {
		global $webexpert_marketplace_filter_hpos_applied;
		if ( ! empty( $webexpert_marketplace_filter_hpos_applied ) ) return $args;
		$filter = isset( $_GET['webexpert_marketplace_filter'] ) ? sanitize_text_field( $_GET['webexpert_marketplace_filter'] ) : '';
		if ( ! $filter ) return $args;
		$options = apply_filters( 'webexpert_marketplace_order_filter_options', [] );
		if ( ! array_key_exists( $filter, $options ) ) return $args;
		$args['created_via'] = $filter;
		$webexpert_marketplace_filter_hpos_applied = true;
		return $args;
	}
}
